<p align="center">
	<img width="755" height="175" src="assets/images/logo.png">
</p>

# Info
Skid Client is an MCBE Utility mod made by: GrandmaaPlays & GrandpaaPlays

Skid Client is a skid of the Horion Client

