#pragma once

#include "Module.h"

class ChatBypass : public IModule {
public:
	ChatBypass();
	virtual const char* getModuleName();
};
#pragma once
