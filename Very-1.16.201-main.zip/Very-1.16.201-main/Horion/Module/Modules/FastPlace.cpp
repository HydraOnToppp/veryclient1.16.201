#include "FastPlace.h"

//FastPlace::FastPlace() : IModule(0, Category::FLIGHT, "Place blocks quickly") {
//}

//const char* FastPlace::getModuleName() {
	//return "FastPlace";
//}