#pragma once

#include "Module.h"

class HiveFly : public IModule {
public:
	//FastPlace();
	virtual const char* getModuleName();
};